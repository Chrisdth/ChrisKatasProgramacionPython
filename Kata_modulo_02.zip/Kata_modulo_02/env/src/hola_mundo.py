message = "Hola mundo!"
print (message)
message = "Hola mundo babosos"
print (message)
# tip de practica 1: intentan ejecutarlo en un notebook 
a = 54
b = 55 
# expresion de prueba
if a < b:
	# instruccion a ejecutar 
	print (b)